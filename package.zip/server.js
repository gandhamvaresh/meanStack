var express = require('express');
var app = express();
var morgan = require('morgan')
var mongoose = require('mongoose');

app.use(morgan('dev'));

const dbname = 'mongodb://gvaresh:gvk$3415@ds243295.mlab.com:43295/meanjsva'
mongoose.connect(dbname)
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
      console.log("Hopppk  " );

});
mongoose.Promise = global.Promise;

app.get('/home', function(req, res){
res.send('Mean Hello world from home');
})
var port = process.env.PORT || 8080;

app.listen(port ,function(){
    console.log("Hello MEAN stack  " + port);
})


